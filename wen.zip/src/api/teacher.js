// src/api/teacher.js
// 老师端相关接口（目前为前端 mock，后续可无缝切换为真实后端接口）
// 约定：所有函数返回 Promise，方便与真实 http 请求保持一致

import {
  mockCreateLesson,
  mockGetTodayLessons,
  mockGetLessonsByDateRange,
  mockGetWeekLessons,
} from './mock/teacher.js'

// ==========================================
// Mock Data Store (In-Memory Database)
// ==========================================
const now = new Date()
const oneDay = 24 * 60 * 60 * 1000

// Helper: Get start/end of current week
function getWeekRange() {
  const d = new Date()
  const day = d.getDay() || 7 // 1(Mon) - 7(Sun)
  const monday = new Date(d.getFullYear(), d.getMonth(), d.getDate() - day + 1)
  const sunday = new Date(monday.getTime() + 6 * oneDay + (24 * 60 * 60 * 1000) - 1)
  return { start: monday, end: sunday }
}

let students = [
  {
    id: 'stu-001',
    name: '李一',
    gender: '男',
    age: 6,
    avatarUrl: '',
    phone: '13800000001',
    course: 'english_k1',
    classId: 'class_a',
    remainingLessons: 8,
    lastLessonAt: new Date(now.getTime() - 1 * oneDay).toISOString(),
    createdAt: new Date(now.getTime() - 10 * oneDay).toISOString(),
    note: '性格活泼，喜欢互动'
  },
  {
    id: 'stu-002',
    name: '王二',
    gender: '女',
    age: 7,
    avatarUrl: '',
    phone: '13800000002',
    course: 'english_p1',
    classId: 'class_b',
    remainingLessons: 2, // Low balance
    lastLessonAt: new Date(now.getTime() - 3 * oneDay).toISOString(),
    createdAt: new Date(now.getTime() - 2 * oneDay).toISOString(), // Created this week (maybe)
    note: '需多关注发音'
  },
  {
    id: 'stu-003',
    name: '张三',
    gender: '男',
    age: 5,
    avatarUrl: '',
    phone: '13800000003',
    course: 'math_basic',
    classId: '1v1_demo',
    remainingLessons: 5,
    lastLessonAt: new Date(now.getTime() - 5 * oneDay).toISOString(),
    createdAt: new Date(now.getTime() - 20 * oneDay).toISOString(),
    note: ''
  },
  {
    id: 'stu-004',
    name: '赵四',
    gender: '女',
    age: 8,
    avatarUrl: '',
    phone: '13800000004',
    course: 'english_p1',
    classId: 'class_a',
    remainingLessons: 10,
    lastLessonAt: new Date(now.getTime() - 7 * oneDay).toISOString(),
    createdAt: new Date().toISOString(), // Just created
    note: '家长要求严格'
  },
]

let reports = []

// ==========================================
// API Methods
// ==========================================

export async function getTeacherStats() {
  return Promise.resolve({
    studentCount: students.length,
    todayLessonCount: 3,
    billingAmount: 1500,
  })
}

// Enhanced getStudentList with filtering
export async function getStudents(params = {}) {
  let list = [...students]

  // Filtering
  if (params.keyword) {
    const kw = params.keyword.trim().toLowerCase()
    list = list.filter(s => s.name.includes(kw) || s.phone.includes(kw))
  }
  if (params.gender && params.gender !== 'all') {
    list = list.filter(s => s.gender === params.gender)
  }
  if (params.course) {
    list = list.filter(s => s.course === params.course)
  }
  if (params.classId) {
    list = list.filter(s => s.classId === params.classId)
  }
  if (params.lowBalance) {
    list = list.filter(s => s.remainingLessons < 3)
  }
  if (params.needsLessonThisWeek) {
    // Mock logic: if last lesson was > 3 days ago, they need a lesson
    const threeDaysAgo = new Date(now.getTime() - 3 * oneDay)
    list = list.filter(s => new Date(s.lastLessonAt) < threeDaysAgo)
  }

  // Sorting
  const sortDir = params.sortDir === 'asc' ? 1 : -1
  list.sort((a, b) => {
    const tA = new Date(a.lastLessonAt).getTime()
    const tB = new Date(b.lastLessonAt).getTime()
    return (tA - tB) * sortDir
  })

  // Pagination (Mock)
  const page = params.page || 1
  const pageSize = params.pageSize || 10
  const start = (page - 1) * pageSize
  const pagedList = list.slice(start, start + pageSize)

  return Promise.resolve({
    list: pagedList,
    total: list.length
  })
}

// Kept for backward compatibility if used elsewhere
export async function getStudentList() {
  return getStudents().then(res => res.list)
}

export async function getWeeklyNewStudentsCount() {
  const { start, end } = getWeekRange()
  const count = students.filter(s => {
    const c = new Date(s.createdAt)
    return c >= start && c <= end
  }).length
  return Promise.resolve(count)
}

export async function createStudent(payload) {
  const newStudent = {
    id: 'stu-' + Date.now(),
    name: payload.name,
    gender: payload.gender || '未知',
    age: payload.age || 0,
    phone: payload.phone,
    course: payload.course,
    classId: payload.classId,
    remainingLessons: parseInt(payload.lessons) || 0,
    lastLessonAt: new Date().toISOString(), // Mock
    createdAt: new Date().toISOString(),
    note: payload.note || ''
  }
  students.unshift(newStudent)
  return Promise.resolve(newStudent)
}

export async function deleteStudent(id) {
  const idx = students.findIndex(s => s.id === id)
  if (idx !== -1) {
    students.splice(idx, 1)
    return Promise.resolve(true)
  }
  return Promise.reject(new Error('Student not found'))
}

export async function getStudentDetail(id) {
  const s = students.find(s => s.id === id)
  if (!s) return Promise.reject(new Error('Student not found'))
  
  // Mock Learning Records
  const history = [
    { title: 'Unit 1: Hello', date: '2023-12-20', accuracy: '95%', score: 10, homework: 'completed' },
    { title: 'Unit 2: Colors', date: '2023-12-15', accuracy: '88%', score: 8, homework: 'completed' },
    { title: 'Unit 3: Numbers', date: '2023-12-10', accuracy: '90%', score: 9, homework: 'missing' },
  ]

  return Promise.resolve({
    ...s,
    history
  })
}

export async function enrollStudent(id, payload) {
  const idx = students.findIndex(s => s.id === id)
  if (idx !== -1) {
    // Update logic (mock)
    students[idx].course = payload.course
    students[idx].classId = payload.classId
    students[idx].remainingLessons += parseInt(payload.lessons) || 0
    students[idx].note = payload.note || students[idx].note
    return Promise.resolve(students[idx])
  }
  return Promise.reject(new Error('Student not found'))
}

export async function updateStudent(id, payload) {
  const idx = students.findIndex(s => s.id === id)
  if (idx !== -1) {
    students[idx] = { ...students[idx], ...payload }
    return Promise.resolve(students[idx])
  }
  return Promise.reject(new Error('Student not found'))
}

export async function createStudentReport(id, payload) {
  reports.push({
    id: 'rep-' + Date.now(),
    studentId: id,
    ...payload,
    createdAt: new Date().toISOString()
  })
  return Promise.resolve(true)
}

// Lesson related exports
export async function createLesson(data) {
  return mockCreateLesson(data)
}
export async function getLessonsByDateRange(startDate, endDate) {
  return mockGetLessonsByDateRange(startDate, endDate)
}
export async function getTodayLessons() {
  return mockGetTodayLessons()
}
export async function getWeekLessons() {
  return mockGetWeekLessons()
}
