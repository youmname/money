<script setup>
// HomeView 现在只作为“占位”
// 如果你未来想让 / 显示某个首页，可在 router 里改 redirect
</script>

<template>
  <div style="padding: 24px;">
    <h1>HomeView（占位）</h1>
    <p>当前项目默认从 / 跳转到 /login。</p>
  </div>
</template>
