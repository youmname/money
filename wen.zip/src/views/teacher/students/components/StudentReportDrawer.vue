<script setup>
import { ref, reactive, watch, onUnmounted, computed } from 'vue'
import BaseButton from '@/components/base/BaseButton.vue'
import { createStudentReport } from '@/api/teacher'

const props = defineProps({
  modelValue: Boolean,
  student: Object,
  embedded: { type: Boolean, default: false }
})

const emit = defineEmits(['update:modelValue', 'success'])

const form = ref({
  level: 'K1',
  wordCount: 50,
  attended: 12,
  suggestion: ''
})
const loading = ref(false)

// 全屏状态
const isFullscreen = ref(false)

// 报告模板数据（可扩展）
const reportData = reactive({
  studentName: computed(() => props.student?.name || ''),
  course: computed(() => props.student?.course || ''),
  classId: computed(() => props.student?.classId || ''),
  period: '2025-12-16 ~ 2025-12-23', // 可动态生成
  wordLevel: computed(() => form.value.level),
  wordCount: computed(() => form.value.wordCount),
  attended: computed(() => form.value.attended),
  suggestion: computed(() => form.value.suggestion),
  // 占位数据
  accuracy: '92%',
  homeworkCompletion: '95%',
  avgScore: 8.7,
  topMistakes: ['apple', 'banana', 'cat'],
  progressChart: [60, 75, 82, 88, 92, 95, 98]
})

function close() {
  emit('update:modelValue', false)
}

function toggleFullscreen() {
  isFullscreen.value = !isFullscreen.value
}

async function handleSubmit() {
  loading.value = true
  try {
    await createStudentReport(props.student.id, form.value)
    emit('success')
    close()
  } catch (e) {
    alert(e.message)
  } finally {
    loading.value = false
  }
}

function exportPDF(type = 'report') {
  alert(`正在生成 ${type} PDF... (Mock)`)
}

function onKeydown(e) {
  if (e.key === 'Escape' && props.modelValue && !isFullscreen.value) close()
}

watch(() => props.modelValue, (val) => {
  if (val) {
    window.addEventListener('keydown', onKeydown)
    // 重置表单
    form.value = {
      level: 'K1',
      wordCount: 50,
      attended: 12,
      suggestion: ''
    }
  } else {
    window.removeEventListener('keydown', onKeydown)
    isFullscreen.value = false
  }
})

onUnmounted(() => {
  window.removeEventListener('keydown', onKeydown)
})
</script>

<template>
  <Teleport v-if="!embedded" to="body">
    <Transition name="drawer-fade">
      <div v-if="modelValue" class="drawerMask" @click="close">
        <div 
          class="drawerContainer"
          :class="{ 'fullscreen': isFullscreen }"
          @click.stop
        >
          
          <header class="drawerHeader">
            <div class="headerLeft">
              <h2 class="drawerTitle">学习报告</h2>
              <span class="studentName">{{ reportData.studentName }}</span>
            </div>
            <div class="headerRight">
              <button class="iconBtn" @click="toggleFullscreen" :title="isFullscreen ? '退出全屏' : '全屏'">
                {{ isFullscreen ? '⤓' : '⤢' }}
              </button>
              <button class="closeBtn" @click="close">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M18 6L6 18M6 6l12 12" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </button>
            </div>
          </header>

          <div class="drawerContent" :class="{ 'fullscreenContent': isFullscreen }">
            
            <!-- 学生信息摘要 -->
            <section class="section">
              <div class="sectionHeader">
                <h3 class="sectionTitle">学生信息摘要</h3>
              </div>
              <div class="infoGrid">
                <div class="infoItem">
                  <span class="label">姓名</span>
                  <span class="value">{{ reportData.studentName }}</span>
                </div>
                <div class="infoItem">
                  <span class="label">课程</span>
                  <span class="value">{{ reportData.course }}</span>
                </div>
                <div class="infoItem">
                  <span class="label">班级</span>
                  <span class="value">{{ reportData.classId }}</span>
                </div>
                <div class="infoItem">
                  <span class="label">统计周期</span>
                  <span class="value">{{ reportData.period }}</span>
                </div>
              </div>
            </section>

            <!-- 单词掌握情况 -->
            <section class="section">
              <div class="sectionHeader">
                <h3 class="sectionTitle">单词掌握情况</h3>
              </div>
              <div class="wordStats">
                <div class="statCard">
                  <div class="statValue">{{ reportData.wordCount }}</div>
                  <div class="statLabel">掌握词汇量</div>
                </div>
                <div class="statCard">
                  <div class="statValue">{{ reportData.wordLevel }}</div>
                  <div class="statLabel">当前等级</div>
                </div>
                <div class="statCard">
                  <div class="statValue">{{ reportData.accuracy }}</div>
                  <div class="statLabel">平均准确率</div>
                </div>
              </div>
              
              <!-- 进度图表（占位） -->
              <div class="chartContainer">
                <div class="chartTitle">学习进度趋势</div>
                <div class="progressBars">
                  <div 
                    v-for="(val, idx) in reportData.progressChart" 
                    :key="idx"
                    class="progressBar"
                    :style="{ height: `${val}%` }"
                  ></div>
                </div>
              </div>
            </section>

            <!-- 学习表现统计 -->
            <section class="section">
              <div class="sectionHeader">
                <h3 class="sectionTitle">学习表现统计</h3>
              </div>
              <div class="performanceGrid">
                <div class="perfCard">
                  <div class="perfIcon">📚</div>
                  <div class="perfValue">{{ reportData.attended }}</div>
                  <div class="perfLabel">已上课次</div>
                </div>
                <div class="perfCard">
                  <div class="perfIcon">✅</div>
                  <div class="perfValue">{{ reportData.homeworkCompletion }}</div>
                  <div class="perfLabel">作业完成率</div>
                </div>
                <div class="perfCard">
                  <div class="perfIcon">⭐</div>
                  <div class="perfValue">{{ reportData.avgScore }}</div>
                  <div class="perfLabel">平均得分</div>
                </div>
              </div>
            </section>

            <!-- 常见错题 -->
            <section class="section">
              <div class="sectionHeader">
                <h3 class="sectionTitle">常见错题</h3>
              </div>
              <div class="mistakeList">
                <div v-for="word in reportData.topMistakes" :key="word" class="mistakeItem">
                  <span class="word">{{ word }}</span>
                  <span class="count">3次</span>
                </div>
              </div>
            </section>

            <!-- 老师建议 -->
            <section class="section">
              <div class="sectionHeader">
                <h3 class="sectionTitle">老师建议</h3>
              </div>
              <div class="formGroup">
                <label>当前单词等级</label>
                <select v-model="form.level" class="nativeSelect">
                  <option>K1</option>
                  <option>K2</option>
                  <option>P1</option>
                  <option>P2</option>
                </select>
              </div>
              <div class="formGroup">
                <label>掌握词汇量</label>
                <input type="number" v-model="form.wordCount" class="nativeInput" />
              </div>
              <div class="formGroup">
                <label>已上课次</label>
                <input type="number" v-model="form.attended" class="nativeInput" />
              </div>
              <div class="formGroup">
                <label>老师建议</label>
                <textarea v-model="form.suggestion" rows="4" class="nativeTextarea" placeholder="请输入学习建议..."></textarea>
              </div>
            </section>

          </div>

          <footer class="drawerFooter">
            <div class="footerLeft">
              <BaseButton variant="secondary" @click="close" :disabled="loading">取消</BaseButton>
            </div>
            <div class="footerRight">
              <BaseButton variant="secondary" @click="exportPDF('preview')">预览PDF</BaseButton>
              <BaseButton variant="primary" :loading="loading" @click="handleSubmit">生成并保存</BaseButton>
            </div>
          </footer>

        </div>
      </div>
    </Transition>
  </Teleport>
  <div v-else class="drawerContainer" :class="{ 'fullscreen': isFullscreen }">
    <header class="drawerHeader">
      <div class="headerLeft">
        <h2 class="drawerTitle">学习报告</h2>
        <span class="studentName">{{ reportData.studentName }}</span>
      </div>
      <div class="headerRight">
        <button class="iconBtn" @click="toggleFullscreen" :title="isFullscreen ? '退出全屏' : '全屏'">
          {{ isFullscreen ? '⤓' : '⤢' }}
        </button>
      </div>
    </header>

    <div class="drawerContent" :class="{ 'fullscreenContent': isFullscreen }">
      <!-- 学生信息摘要 -->
      <section class="section">
        <div class="sectionHeader">
          <h3 class="sectionTitle">学生信息摘要</h3>
        </div>
        <div class="infoGrid">
          <div class="infoItem"><span class="label">姓名</span><span class="value">{{ reportData.studentName }}</span></div>
          <div class="infoItem"><span class="label">课程</span><span class="value">{{ reportData.course }}</span></div>
          <div class="infoItem"><span class="label">班级</span><span class="value">{{ reportData.classId }}</span></div>
          <div class="infoItem"><span class="label">统计周期</span><span class="value">{{ reportData.period }}</span></div>
        </div>
      </section>

      <!-- 单词掌握情况 -->
      <section class="section">
        <div class="sectionHeader">
          <h3 class="sectionTitle">单词掌握情况</h3>
        </div>
        <div class="wordStats">
          <div class="statCard"><div class="statValue">{{ reportData.wordCount }}</div><div class="statLabel">掌握词汇量</div></div>
          <div class="statCard"><div class="statValue">{{ reportData.wordLevel }}</div><div class="statLabel">当前等级</div></div>
          <div class="statCard"><div class="statValue">{{ reportData.accuracy }}</div><div class="statLabel">平均准确率</div></div>
        </div>
        <div class="chartContainer">
          <div class="chartTitle">学习进度趋势</div>
          <div class="progressBars">
            <div v-for="(val, idx) in reportData.progressChart" :key="idx" class="progressBar" :style="{ height: `${val}%` }"></div>
          </div>
        </div>
      </section>

      <!-- 学习表现统计 -->
      <section class="section">
        <div class="sectionHeader">
          <h3 class="sectionTitle">学习表现统计</h3>
        </div>
        <div class="performanceGrid">
          <div class="perfCard"><div class="perfIcon">📚</div><div class="perfValue">{{ reportData.attended }}</div><div class="perfLabel">已上课次</div></div>
          <div class="perfCard"><div class="perfIcon">✅</div><div class="perfValue">{{ reportData.homeworkCompletion }}</div><div class="perfLabel">作业完成率</div></div>
          <div class="perfCard"><div class="perfIcon">⭐</div><div class="perfValue">{{ reportData.avgScore }}</div><div class="perfLabel">平均得分</div></div>
        </div>
      </section>

      <!-- 常见错题 -->
      <section class="section">
        <div class="sectionHeader">
          <h3 class="sectionTitle">常见错题</h3>
        </div>
        <div class="mistakeList">
          <div v-for="word in reportData.topMistakes" :key="word" class="mistakeItem">
            <span class="word">{{ word }}</span>
            <span class="count">3次</span>
          </div>
        </div>
      </section>

      <!-- 老师建议 -->
      <section class="section">
        <div class="sectionHeader">
          <h3 class="sectionTitle">老师建议</h3>
        </div>
        <div class="formGroup">
          <label>当前单词等级</label>
          <select v-model="form.level" class="nativeSelect">
            <option>K1</option><option>K2</option><option>P1</option><option>P2</option>
          </select>
        </div>
        <div class="formGroup">
          <label>掌握词汇量</label>
          <input type="number" v-model="form.wordCount" class="nativeInput" />
        </div>
        <div class="formGroup">
          <label>已上课次</label>
          <input type="number" v-model="form.attended" class="nativeInput" />
        </div>
        <div class="formGroup">
          <label>老师建议</label>
          <textarea v-model="form.suggestion" rows="4" class="nativeTextarea" placeholder="请输入学习建议..."></textarea>
        </div>
      </section>
    </div>

    <footer class="drawerFooter">
      <div class="footerLeft">
        <BaseButton variant="secondary" @click="close" :disabled="loading">取消</BaseButton>
      </div>
      <div class="footerRight">
        <BaseButton variant="secondary" @click="exportPDF('preview')">预览PDF</BaseButton>
        <BaseButton variant="primary" :loading="loading" @click="handleSubmit">生成并保存</BaseButton>
      </div>
    </footer>
  </div>
</template>

<style scoped>
/* 抽屉基础样式 */
.drawerMask {
  position: fixed; inset: 0; z-index: 1000;
  background: rgba(15, 23, 42, 0.45); backdrop-filter: blur(2px);
  display: flex; justify-content: flex-end;
}
.drawerContainer {
  width: 100%; max-width: 540px; height: 100%; background: #fff;
  box-shadow: -10px 0 40px rgba(0, 0, 0, 0.1);
  display: flex; flex-direction: column;
  transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
}
.drawerContainer.fullscreen {
  max-width: 100vw; width: 100vw;
  transition: all 0.3s ease;
}

.drawer-fade-enter-active, .drawer-fade-leave-active { transition: opacity 0.3s ease; }
.drawer-fade-enter-from, .drawer-fade-leave-to { opacity: 0; }
.drawer-fade-enter-active .drawerContainer, .drawer-fade-leave-active .drawerContainer { transform: translateX(100%); }

/* Header */
.drawerHeader {
  position: sticky; top: 0; z-index: 10; background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(12px); border-bottom: 1px solid #e2e8f0; flex-shrink: 0;
  display: flex; justify-content: space-between; align-items: center; padding: 16px 24px;
}
.headerLeft { display: flex; align-items: center; gap: 12px; }
.headerRight { display: flex; align-items: center; gap: 8px; }
.drawerTitle { margin: 0; font-size: 20px; font-weight: 800; color: #0f172a; }
.studentName { font-size: 14px; color: #64748b; }

.closeBtn, .iconBtn {
  background: transparent; border: none; cursor: pointer; padding: 8px;
  border-radius: 50%; color: #64748b; transition: background 0.2s;
}
.closeBtn:hover, .iconBtn:hover { background: #f1f5f9; color: #0f172a; }

/* Content */
.drawerContent {
  flex: 1; overflow-y: auto; padding: 24px; background: #f8fafc;
  display: flex; flex-direction: column; gap: 16px;
}
.drawerContent.fullscreenContent {
  padding: 32px; gap: 24px;
}

.section { background: #fff; border-radius: 16px; border: 1px solid #e2e8f0; overflow: hidden; }
.sectionHeader { padding: 16px 20px; background: #f8fafc; border-bottom: 1px solid #f1f5f9; }
.sectionTitle { margin: 0; font-weight: 700; color: #1e293b; }

.infoGrid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; padding: 20px; }
.infoItem { display: flex; flex-direction: column; gap: 4px; }
.label { font-size: 12px; color: #666; }
.value { font-size: 14px; color: #333; font-weight: 500; }

/* Word Stats */
.wordStats { padding: 20px; display: flex; gap: 16px; }
.statCard { background: #f0f9ff; border: 1px solid #bfdbfe; border-radius: 12px; padding: 16px; text-align: center; flex: 1; }
.statValue { font-size: 24px; font-weight: 800; color: #2563eb; }
.statLabel { font-size: 12px; color: #64748b; margin-top: 4px; }

/* Chart */
.chartContainer { padding: 20px; }
.chartTitle { font-size: 14px; color: #475569; margin-bottom: 12px; }
.progressBars { display: flex; align-items: flex-end; gap: 4px; height: 80px; background: #f1f5f9; border-radius: 8px; padding: 8px; }
.progressBar { flex: 1; background: #3b82f6; border-radius: 4px; min-height: 10px; transition: height 0.3s ease; }

/* Performance */
.performanceGrid { padding: 20px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
.perfCard { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px; text-align: center; }
.perfIcon { font-size: 24px; margin-bottom: 8px; }
.perfValue { font-size: 20px; font-weight: 700; color: #0f172a; }
.perfLabel { font-size: 12px; color: #64748b; margin-top: 4px; }

/* Mistakes */
.mistakeList { padding: 20px; display: flex; flex-direction: column; gap: 8px; }
.mistakeItem { display: flex; justify-content: space-between; align-items: center; background: #fef2f2; border: 1px solid #fca5a5; border-radius: 8px; padding: 8px 12px; }
.mistakeItem .word { font-weight: 600; color: #7f1d1d; }
.mistakeItem .count { font-size: 12px; color: #991b1b; }

/* Form */
.formGroup { padding: 0 20px 16px; display: flex; flex-direction: column; gap: 8px; }
.formGroup label { font-size: 13px; font-weight: 600; color: #475569; }
.nativeSelect, .nativeInput, .nativeTextarea {
  width: 100%; padding: 8px 12px; border: 1px solid #e2e8f0; border-radius: 8px;
  background: #fff; font-size: 14px; color: #1e293b; outline: none;
}
.nativeSelect, .nativeInput { height: 40px; }
.nativeTextarea { resize: vertical; }
.nativeSelect:focus, .nativeInput:focus, .nativeTextarea:focus {
  border-color: #3b82f6; box-shadow: 0 0 0 3px rgba(59,130,246,0.1);
}

/* Footer */
.drawerFooter {
  position: sticky; bottom: 0; z-index: 10; background: #fff;
  border-top: 1px solid #e2e8f0; padding: 16px 24px;
  display: flex; justify-content: space-between; align-items: center; flex-shrink: 0;
}
.footerRight { display: flex; align-items: center; gap: 12px; }

/* 全屏模式调整 */
.drawerContainer.fullscreen .drawerContent {
  padding: 32px;
  gap: 24px;
}
.drawerContainer.fullscreen .section {
  border-radius: 20px;
}
.drawerContainer.fullscreen .sectionHeader {
  padding: 20px 24px;
}
</style>
