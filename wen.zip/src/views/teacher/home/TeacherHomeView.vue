<script setup>
// ==========================
// TeacherHomeView：教师端首页（Hub & Spoke 星系布局）
// 需求要点：顶部 4 个入口（首页/学生管理/课程/题库分类）+ 右侧个人信息。
// ==========================

import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import GlassCard from '@/components/common/GlassCard.vue'
import BaseButton from '@/components/base/BaseButton.vue'
import Loading from '@/components/base/Loading.vue'
import EmptyState from '@/components/base/EmptyState.vue'

import { getTodayLessons } from '@/api/teacher'

const router = useRouter()

const isLoading = ref(true)
const todayLessons = ref([])

const nextLesson = computed(() => {
  if (!todayLessons.value?.length) return null
  const sorted = [...todayLessons.value].sort((a, b) =>
    (a.startTime || '').localeCompare(b.startTime || '')
  )
  return sorted[0] || null
})

async function load() {
  isLoading.value = true
  try {
    const list = await getTodayLessons()
    todayLessons.value = Array.isArray(list) ? list : []
  } finally {
    isLoading.value = false
  }
}

function goSchedule() {
  router.push('/teacher/schedule')
}

function goStudents() {
  router.push('/teacher/students')
}

function goBilling() {
  router.push('/teacher/billing')
}

function goCourse() {
  router.push('/teacher/course')
}

function goQuestionBank() {
  router.push('/teacher/question-bank')
}

function enterClassroom() {
  if (!nextLesson.value?.lessonId) return
  router.push(`/teacher/classroom/${nextLesson.value.lessonId}`)
}

onMounted(load)
</script>

<template>
  <div class="teacherHome">
    <div class="mainColumns">
      <div class="sideStack sideStack--left">
        <GlassCard class="stackCard" variant="light" padding="md">
          <h3 class="hubTitle">学生预警</h3>
          <p class="hubDesc">低出勤 / 课时不足 / 最近学习断档（P0 先占位）</p>
          <div class="hubKpiRow">
            <div class="hubKpi">
              <div class="hubKpi__num">3</div>
              <div class="hubKpi__label">需关注</div>
            </div>
            <div class="hubKpi">
              <div class="hubKpi__num">1</div>
              <div class="hubKpi__label">待联系</div>
            </div>
          </div>
          <BaseButton type="ghost" class="hubBtn" @click="goStudents">查看学生</BaseButton>
        </GlassCard>
        <GlassCard class="stackCard" variant="light" padding="md">
          <h3 class="hubTitle">作业批改</h3>
          <p class="hubDesc">待批改作业列表（占位）</p>
          <BaseButton type="ghost" class="hubBtn" @click="goSchedule">查看作业</BaseButton>
        </GlassCard>
      </div>

      <GlassCard class="columnCard columnCard--center" variant="strong" padding="md">
        <h2 class="centerTitle">下一节课</h2>

        <div v-if="isLoading" class="centerState">
          <Loading />
        </div>

        <div v-else-if="!nextLesson" class="centerState">
          <EmptyState title="今天暂无课程" desc="你可以去课程里安排排课。" />
          <BaseButton type="primary" class="centerCta" @click="goSchedule">去排课</BaseButton>
        </div>

        <div v-else class="centerBody">
          <div class="lessonMeta">
            <div class="lessonMeta__time">
              {{ nextLesson.startTime }} – {{ nextLesson.endTime }}
            </div>
            <div class="lessonMeta__title">{{ nextLesson.title || '课程' }}</div>
            <div class="lessonMeta__sub">
              {{ nextLesson.className || '未选择班级' }} · {{ nextLesson.teacherName || '教师' }}
            </div>
          </div>

          <div class="centerActions">
            <BaseButton type="primary" @click="enterClassroom">进入课堂</BaseButton>
            <BaseButton type="secondary" @click="goSchedule">查看日程</BaseButton>
          </div>
        </div>
      </GlassCard>

      <div class="sideStack sideStack--right">
        <GlassCard class="stackCard" variant="light" padding="md">
          <h3 class="hubTitle">导航入口</h3>
          <p class="hubDesc">快速进入学生、课程与题库工作台。</p>
          <div class="hubKpiRow">
            <BaseButton type="ghost" class="hubBtn" @click="goStudents">学生</BaseButton>
            <BaseButton type="ghost" class="hubBtn" @click="goCourse">课程</BaseButton>
          </div>
          <BaseButton type="ghost" class="hubBtn" @click="goQuestionBank">题库</BaseButton>
        </GlassCard>
        <GlassCard class="stackCard" variant="light" padding="md">
          <h3 class="hubTitle">通知</h3>
          <p class="hubDesc">系统通知和消息（占位）</p>
          <BaseButton type="ghost" class="hubBtn" @click="goBilling">查看账单</BaseButton>
        </GlassCard>
      </div>
    </div>

    <GlassCard class="bottomBar" variant="light" padding="md">
      <div class="bottomBarContent">
        <div class="summaryItem">
          <div class="summaryLabel">本周授课</div>
          <div class="summaryValue">5 节</div>
        </div>

        <div class="summaryItem">
          <div class="summaryLabel">累计课时</div>
          <div class="summaryValue">128 小时</div>
        </div>

        <div class="summaryItem">
          <div class="summaryLabel">续费率</div>
          <div class="summaryValue">100%</div>
        </div>
      </div>
    </GlassCard>
  </div>
</template>

<style scoped>
.teacherHome {
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: var(--space-lg);
}

.mainColumns {
  display: grid;
  grid-template-columns: 1fr 1.35fr 1fr;
  gap: var(--space-lg);
  min-height: 500px;
}

.columnCard {
  height: 100%;
}

.sideStack {
  height: 100%;
  display: grid;
  grid-template-rows: 1fr 1fr;
  gap: var(--space-lg);
}

.stackCard {
  height: 100%;
}

.hubTitle {
  margin: 0;
  font-size: var(--font-title-size);
}

.hubDesc {
  margin: 8px 0 0;
  opacity: 0.8;
}

.hubKpiRow {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--space-md);
  margin-top: var(--space-md);
}

.hubKpi {
  padding: var(--space-md);
  border-radius: var(--radius-sm);
  background: rgba(255, 255, 255, 0.55);
}

.hubKpi__num {
  font-size: 28px;
  font-weight: 700;
}

.hubKpi__label {
  margin-top: 4px;
  opacity: 0.75;
}

.hubBtn {
  margin-top: var(--space-md);
}

.centerTitle {
  margin: 0;
  font-size: 22px;
}

.centerState {
  margin-top: var(--space-md);
}

.centerCta {
  margin-top: var(--space-md);
}

.centerBody {
  margin-top: var(--space-md);
  display: flex;
  flex-direction: column;
  gap: var(--space-md);
}

.lessonMeta__time {
  font-weight: 700;
}

.lessonMeta__title {
  margin-top: 6px;
  font-size: 18px;
  font-weight: 700;
}

.lessonMeta__sub {
  margin-top: 6px;
  opacity: 0.8;
}

.centerActions {
  display: flex;
  gap: var(--space-md);
  flex-wrap: wrap;
}

.todoList {
  margin: var(--space-md) 0 0;
  padding-left: 18px;
  line-height: 1.8;
}

.bottomBar {
  width: 100%;
  margin-top: auto;
}

.bottomBarContent {
  display: flex;
  align-items: center;
  justify-content: space-around;
  gap: var(--space-lg);
}

.summaryItem {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-sm);
}

.summaryLabel {
  font-size: 14px;
  opacity: 0.7;
  color: rgba(15, 23, 42, 0.8);
}

.summaryValue {
  font-size: 20px;
  font-weight: 700;
  color: rgba(15, 23, 42, 0.9);
}

@media (max-width: 1023.98px) {
  .mainColumns {
    grid-template-columns: 1fr;
    grid-template-rows: auto;
  }

  .bottomBarContent {
    flex-direction: column;
    align-items: flex-start;
    gap: var(--space-md);
  }
}
</style>


