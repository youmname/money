<script setup>
import { useRouter } from 'vue-router'
import ClassAdd from './ClassAdd.vue'
import TeacherSchedule from './TeacherSchedule.vue'
import CourseContent from './CourseContent.vue'
import BaseButton from '@/components/base/BaseButton.vue'
import GlassCard from '@/components/common/GlassCard.vue'

const router = useRouter()

function go(path) {
  router.push(path)
}
</script>

<template>
  <section class="coursePage">
    <header class="header">
      <h1 class="title">课程工作台</h1>
      <p class="sub">创建班级、查看排课与管理课程内容。</p>
    </header>

    <div class="grid">
      <GlassCard class="panel" variant="light" padding="md">
        <ClassAdd />
        <BaseButton type="primary" @click="go('/teacher/course/class-add')">进入</BaseButton>
      </GlassCard>
      <GlassCard class="panel" variant="light" padding="md">
        <TeacherSchedule />
        <BaseButton type="primary" @click="go('/teacher/schedule')">进入</BaseButton>
      </GlassCard>
      <GlassCard class="panel" variant="light" padding="md">
        <CourseContent />
        <BaseButton type="primary" @click="go('/teacher/course/content')">进入</BaseButton>
      </GlassCard>
    </div>
  </section>
</template>

<style scoped>
@import '@/assets/base-tokens.css';
@import '@/assets/responsive-tokens.css';

.coursePage {
  display: flex;
  flex-direction: column;
  gap: var(--space-lg);
}

.header {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.title {
  margin: 0;
  font-size: var(--font-size-xl);
  font-weight: 800;
}

.sub {
  margin: 0;
  color: var(--base-text-secondary);
  font-size: var(--font-size-sm);
}

.grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: var(--space-md);
}

.panel {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

@media (max-width: 1023.98px) {
  .grid {
    grid-template-columns: 1fr;
  }
}
</style>


