<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import GlassCard from '@/components/common/GlassCard.vue'
import Loading from '@/components/base/Loading.vue'
import EmptyState from '@/components/base/EmptyState.vue'
import BaseButton from '@/components/base/BaseButton.vue'
import ScheduleGrid from '@/components/teacher/ScheduleGrid.vue'
import CreateLessonModal from '@/components/teacher/CreateLessonModal.vue'
import { createLesson, getLessonsByDateRange } from '@/api/teacher.js'

const router = useRouter()

const startHour = 6
const endHour = 24
const slotMinutes = 15
const defaultDuration = 60

const selectedDate = ref(new Date().toISOString().slice(0, 10))
const lessons = ref([])
const isLoading = ref(true)
const isError = ref(false)
const errorMessage = ref('')

const isModalOpen = ref(false)
const modalStart = ref('')
const modalEnd = ref('')

const classOptions = ref([
  { id: 'class-1', name: '初一 A 班' },
  { id: 'class-2', name: '初一 B 班' },
  { id: 'class-3', name: '口语提升班' },
])

const timeSlots = computed(() => {
  const slots = []
  for (let hour = startHour; hour < endHour; hour++) {
    for (let minute = 0; minute < 60; minute += slotMinutes) {
      const time = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`
      slots.push({ time, hour, minute })
    }
  }
  return slots
})

const lessonsForDay = computed(() =>
  lessons.value.filter((l) => l.startAt.split(' ')[0] === selectedDate.value)
)

const lessonBlocks = computed(() => {
  return lessonsForDay.value.map((lesson) => {
    const [datePart, startTime] = lesson.startAt.split(' ')
    const endTime = lesson.endAt.split(' ')[1]
    const [sh, sm] = startTime.split(':').map(Number)
    const [eh, em] = endTime.split(':').map(Number)
    const startMinutes = sh * 60 + sm
    const endMinutes = eh * 60 + em
    const startIndex = (startMinutes - startHour * 60) / slotMinutes
    const heightSlots = Math.max((endMinutes - startMinutes) / slotMinutes, 1)
    return {
      title: lesson.courseName,
      startLabel: startTime,
      endLabel: endTime,
      top: startIndex,
      height: heightSlots,
      lessonId: lesson.lessonId,
    }
  })
})

async function loadLessons() {
  isLoading.value = true
  isError.value = false
  errorMessage.value = ''
  try {
    const list = await getLessonsByDateRange(selectedDate.value, selectedDate.value)
    lessons.value = Array.isArray(list) ? list : []
  } catch (err) {
    console.error('加载课程失败', err)
    isError.value = true
    errorMessage.value = '课程数据加载失败，请稍后再试'
  } finally {
    isLoading.value = false
  }
}

onMounted(loadLessons)
watch(selectedDate, loadLessons)

function snapTimeTo15(time) {
  const [hStr, mStr] = time.split(':')
  let h = Number(hStr)
  let m = Number(mStr)
  const snapped = Math.round(m / slotMinutes) * slotMinutes
  if (snapped === 60) {
    h += 1
    m = 0
  } else {
    m = snapped
  }
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`
}

function addMinutes(datetimeStr, minutes) {
  const dt = new Date(datetimeStr)
  dt.setMinutes(dt.getMinutes() + minutes)
  return dt.toISOString().slice(0, 16)
}

function handleSelectSlot(slot) {
  const snapped = snapTimeTo15(slot.time)
  const start = `${selectedDate.value}T${snapped}`
  modalStart.value = start
  modalEnd.value = addMinutes(start, defaultDuration)
  isModalOpen.value = true
}

async function handleConfirmLesson(form) {
  try {
    const classItem = classOptions.value.find((c) => c.id === form.classId)
    await createLesson({
      courseName: form.courseName.trim(),
      className: classItem ? classItem.name : '',
      startAt: form.startTime.replace('T', ' '),
      endAt: form.endTime.replace('T', ' '),
      remark: form.remark?.trim() || '',
    })
    await loadLessons()
  } catch (err) {
    console.error('创建课程失败', err)
    alert('创建课程失败，请稍后再试')
  }
}

function handleEnterLesson(lessonId) {
  router.push(`/teacher/classroom/${lessonId}`)
}
</script>

<template>
  <div class="page">
    <div class="page__header">
      <div class="left">
        <BaseButton type="secondary" @click="router.push('/teacher/course')">返回课程工作台</BaseButton>
        <div>
          <div class="page__title">排课日程</div>
          <div class="page__hint">点击空白格即可创建课程（自动吸附 15 分钟刻度）</div>
        </div>
      </div>
      <div class="page__actions">
        <input v-model="selectedDate" type="date" class="datePicker" />
        <BaseButton variant="primary" @click="handleSelectSlot({ time: '10:00' })">
          + 新建课程
        </BaseButton>
      </div>
    </div>

    <GlassCard class="page__grid" variant="strong" padding="none">
      <div class="gridWrap">
        <div v-if="isLoading" class="stateWrapper">
          <Loading text="加载中..." />
        </div>
        <div v-else-if="isError" class="stateWrapper">
          <EmptyState icon="⚠" title="加载失败" :description="errorMessage" />
        </div>
        <ScheduleGrid
          v-else
          :slots="timeSlots"
          :lesson-blocks="lessonBlocks"
          :cell-height="28"
          @select="handleSelectSlot"
          @enter="handleEnterLesson"
        />
      </div>
    </GlassCard>

    <CreateLessonModal
      v-model:open="isModalOpen"
      :start-time="modalStart"
      :end-time="modalEnd"
      :class-options="classOptions"
      @confirm="handleConfirmLesson"
    />
  </div>
</template>

<style scoped>
.page {
  display: flex;
  flex-direction: column;
  gap: var(--space-md);
  min-height: calc(100vh - 120px);
}

.page__header {
  display: flex;
  align-items: center;
  gap: var(--space-md);
  flex-wrap: wrap;
  justify-content: space-between;
}

.left {
  display: flex;
  align-items: center;
  gap: var(--space-md);
}

.page__title {
  font-size: 20px;
  font-weight: 800;
  color: var(--base-text);
}

.page__hint {
  font-size: 12px;
  color: var(--base-muted);
}

.page__actions {
  margin-left: auto;
  display: flex;
  align-items: center;
  gap: var(--space-sm);
}

.datePicker {
  height: 40px;
  border-radius: var(--base-radius-md);
  border: 1px solid var(--base-color-border);
  padding: 0 var(--space-sm);
}

.page__grid {
  flex: 1;
  min-height: 520px;
  overflow: hidden;
}

.gridWrap {
  height: 100%;
  overflow: auto;
  padding: 10px;
}

.stateWrapper {
  min-height: 420px;
  display: grid;
  place-items: center;
}

@media (max-width: 768px) {
  .page__header {
    flex-direction: column;
    align-items: flex-start;
  }

  .page__actions {
    width: 100%;
    justify-content: space-between;
  }
}
</style>