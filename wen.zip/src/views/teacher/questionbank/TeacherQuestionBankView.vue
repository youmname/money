<script setup>
import { useRouter } from 'vue-router'
import WordQuestionBank from './components/WordQuestionBank.vue'
import ReadingQuestionBank from './components/ReadingQuestionBank.vue'
import GrammarQuestionBank from './components/GrammarQuestionBank.vue'
import WriteQuestionBank from './components/WriteQuestionBank.vue'
import BaseButton from '@/components/base/BaseButton.vue'
import GlassCard from '@/components/common/GlassCard.vue'

const router = useRouter()

function go(path) {
  router.push(path)
}
</script>

<template>
  <section class="page">
    <header class="page__header">
      <h1 class="page__title">题库工作台</h1>
      <p class="page__sub">按题型拆分成 4 个板块，方便后续分别扩展。</p>
    </header>

    <div class="grid">
      <GlassCard class="panel" variant="light" padding="md">
        <WordQuestionBank />
        <BaseButton type="primary" @click="go('/teacher/question-bank/word')">进入</BaseButton>
      </GlassCard>
      <GlassCard class="panel" variant="light" padding="md">
        <ReadingQuestionBank />
        <BaseButton type="primary" @click="go('/teacher/question-bank/reading')">进入</BaseButton>
      </GlassCard>
      <GlassCard class="panel" variant="light" padding="md">
        <GrammarQuestionBank />
        <BaseButton type="primary" @click="go('/teacher/question-bank/grammar')">进入</BaseButton>
      </GlassCard>
      <GlassCard class="panel" variant="light" padding="md">
        <WriteQuestionBank />
        <BaseButton type="primary" @click="go('/teacher/question-bank/write')">进入</BaseButton>
      </GlassCard>
    </div>
  </section>
</template>

<style scoped>
@import '@/assets/base-tokens.css';

.page {
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: var(--space-md);
}

.page__header {
  margin-bottom: 4px;
}

.page__title {
  margin: 0;
  font-size: 20px;
  font-weight: 800;
  letter-spacing: 0.2px;
}

.page__sub {
  margin: 6px 0 0;
  color: var(--base-color-text-secondary);
  font-size: 13px;
}

.grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 14px;
}

.panel {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

@media (max-width: 768px) {
  .grid {
    grid-template-columns: 1fr;
  }
}
</style>

