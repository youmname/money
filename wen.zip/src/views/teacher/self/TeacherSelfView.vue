<script setup>
import GlassCard from '@/components/common/GlassCard.vue'
import BaseButton from '@/components/base/BaseButton.vue'
</script>

<template>
  <section class="selfPage">
    <h1 class="title">个人中心（占位）</h1>
    <p class="sub">后续将接入个人信息、账号设置与账单入口。</p>

    <GlassCard class="card" variant="light" padding="md">
      <h2 class="cardTitle">基本信息</h2>
      <p class="cardDesc">当前为占位展示，暂未接入真实用户数据。</p>
      <BaseButton type="ghost">编辑个人资料（占位）</BaseButton>
    </GlassCard>
  </section>
</template>

<style scoped>
@import '@/assets/base-tokens.css';

.selfPage {
  display: flex;
  flex-direction: column;
  gap: var(--space-md);
}

.title {
  margin: 0;
  font-size: 22px;
  font-weight: 800;
}

.sub {
  margin: 0;
  font-size: 13px;
  color: var(--base-color-text-secondary);
}

.card {
  max-width: 480px;
}

.cardTitle {
  margin: 0 0 6px;
  font-size: 18px;
  font-weight: 800;
}

.cardDesc {
  margin: 0 0 12px;
  font-size: 14px;
  opacity: 0.8;
}
</style>


