<script setup>
import { computed, reactive } from 'vue'
import BaseButton from '@/components/base/BaseButton.vue'

const props = defineProps({
  slots: { type: Array, default: () => [] },           // [{time:'08:00', hour:8, minute:0}, ...]
  lessonBlocks: { type: Array, default: () => [] },    // [{title,startLabel,endLabel,top,height,lessonId,colorClass,dayKey,meta,style}, ...]
  days: { type: Array, default: () => [] },            // [{key:'YYYY-MM-DD', label:'周一 12/25'}, ...]
  cellHeight: { type: Number, default: 28 },

  slotMinutes: { type: Number, default: 15 },

  todayKey: { type: String, default: '' },
})

const emit = defineEmits(['select', 'select-range', 'enter', 'open'])

const blocksByDay = computed(() => {
  const grouped = {}
  props.days.forEach((day) => { grouped[day.key] = [] })
  props.lessonBlocks.forEach((block) => {
    if (!grouped[block.dayKey]) grouped[block.dayKey] = []
    grouped[block.dayKey].push(block)
  })
  return grouped
})

function parseDateKey(dateStr) {
  const [y, m, d] = dateStr.split('-').map(Number)
  return { y, m, d }
}

function minutesFromTime(t) {
  const [h, m] = t.split(':').map(Number)
  return h * 60 + m
}

function timeFromMinutes(total) {
  const h = Math.floor(total / 60)
  const m = total % 60
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`
}

function addMinutesToTime(t, mins) {
  return timeFromMinutes(minutesFromTime(t) + mins)
}

function formatTooltip(dateKey, startTime, endTime) {
  const { y, m, d } = parseDateKey(dateKey)
  return `${y}年${String(m).padStart(2, '0')}月${String(d).padStart(2, '0')}日 ${startTime} - ${endTime}`
}

const state = reactive({
  dayKey: '',
  startIndex: 0,
  endIndex: 0,
  anchor: null, // { dayKey, index }
})

const hover = reactive({
  visible: false,
  x: 0,
  y: 0,
  text: '',
})

function normalizeRange(a, b) {
  return { min: Math.min(a, b), max: Math.max(a, b) }
}

function buildRangePayload(dayKey, startIdx, endIdx) {
  const { min, max } = normalizeRange(startIdx, endIdx)
  const rawStart = props.slots[min]?.time
  const rawEnd = addMinutesToTime(props.slots[max]?.time, props.slotMinutes)

  if (!rawStart) return null

  return { date: dayKey, startTime: rawStart, endTime: rawEnd }
}

function handleTwoClick(dayKey, index) {
  // 第一次点击：设 anchor
  if (!state.anchor) {
    state.anchor = { dayKey, index }
    state.dayKey = dayKey
    state.startIndex = index
    state.endIndex = index
    return
  }

  // 跨天：重置 anchor
  if (state.anchor.dayKey !== dayKey) {
    state.anchor = { dayKey, index }
    state.dayKey = dayKey
    state.startIndex = index
    state.endIndex = index
    return
  }

  // 第二次点击：形成范围
  const payload = buildRangePayload(dayKey, state.anchor.index, index)
  state.anchor = null
  if (payload) emit('select-range', payload)
}

function onCellMouseEnter(dayKey, index, e) {
  if (state.anchor && state.anchor.dayKey === dayKey) {
    state.endIndex = index
  }

  const startTime = props.slots[index]?.time
  if (!startTime) return
  const endTime = addMinutesToTime(startTime, props.slotMinutes)
  hover.visible = true
  hover.text = formatTooltip(dayKey, startTime, endTime)
  hover.x = e.clientX
  hover.y = e.clientY
}

function onCellMouseMove(e) {
  if (!hover.visible) return
  hover.x = e.clientX
  hover.y = e.clientY
}

function onCellMouseLeave() {
  hover.visible = false
}

function handleCellClick(dayKey, idx) {
  handleTwoClick(dayKey, idx)
}

const selectionOverlayByDay = computed(() => {
  if (!state.anchor) return {}
  const dayKey = state.anchor.dayKey
  const { min, max } = normalizeRange(state.anchor.index, state.endIndex)
  return {
    [dayKey]: { top: min * props.cellHeight, height: (max - min + 1) * props.cellHeight },
  }
})
</script>

<template>
  <div class="scheduleGrid" :style="{ '--cell-h': `${cellHeight}px`, '--day-count': days.length }">
    <div class="timeColumn">
      <div class="timeHeader"></div>
      <div
        v-for="slot in slots"
        :key="slot.time"
        class="timeLabel"
        :style="{ height: 'var(--cell-h)' }"
      >
        <span v-if="slot.minute === 0">{{ slot.time }}</span>
      </div>
    </div>

    <div class="gridArea">
      <div class="dayHeaderRow">
        <div
          v-for="day in days"
          :key="day.key"
          class="dayHeader"
          :class="{ today: day.key === todayKey }"
        >
          {{ day.label }}
        </div>
      </div>

      <div class="dayColumns">
        <div v-for="day in days" :key="day.key" class="dayColumn">
          <div
            v-if="selectionOverlayByDay[day.key]"
            class="selectionOverlay"
            :style="{
              top: selectionOverlayByDay[day.key].top + 'px',
              height: selectionOverlayByDay[day.key].height + 'px',
            }"
          ></div>

          <div
            v-for="(slot, idx) in slots"
            :key="slot.time"
            class="gridCell"
            :style="{ height: 'var(--cell-h)' }"
            @click="handleCellClick(day.key, idx)"
            @mouseenter="onCellMouseEnter(day.key, idx, $event)"
            @mousemove="onCellMouseMove"
            @mouseleave="onCellMouseLeave"
          >
            <span v-if="slot.minute === 0" class="tick"></span>
          </div>

          <div
            v-for="lesson in (blocksByDay[day.key] || [])"
            :key="lesson.lessonId"
            class="lessonBlock"
            :class="lesson.colorClass"
            :style="{
              top: `calc(${lesson.top} * var(--cell-h))`,
              height: `calc(${lesson.height} * var(--cell-h))`,
              ...(lesson.style || {}),
            }"
            @click.stop="emit('open', lesson.lessonId)"
            @mouseenter="hover.visible = true; hover.text = (lesson.meta?.hoverText || `${day.key} ${lesson.startLabel}-${lesson.endLabel} ${lesson.title}`)"
          >
            <div class="lessonTitle">{{ lesson.title }}</div>
            <div class="lessonTime">{{ lesson.startLabel }} - {{ lesson.endLabel }}</div>
            <BaseButton variant="ghost" class="enterBtn" @click.stop="emit('enter', lesson.lessonId)">进入课堂</BaseButton>
          </div>
        </div>
      </div>

      <div
        v-if="hover.visible"
        class="hoverTip"
        :style="{ left: (hover.x + 12) + 'px', top: (hover.y - 36) + 'px' }"
      >
        {{ hover.text }}
      </div>
    </div>
  </div>
</template>

<style scoped>
@import '@/assets/base-tokens.css';

.scheduleGrid {
  --cell-h: 28px;
  display: grid;
  grid-template-columns: 96px 1fr;
  gap: var(--space-sm);
  width: 100%;
  height: 100%;
}

.timeColumn {
  background: #f8fafc;
  border-radius: var(--card-radius-lg);
  border: 1px solid var(--base-color-border);
  overflow: hidden;
}

.timeHeader {
  height: 40px;
  border-bottom: 1px solid rgba(226, 232, 240, 0.9);
  background: #f8fafc;
  position: sticky;
  top: 0;
  z-index: 5;
}

.timeLabel {
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  color: rgba(100, 116, 139, 1);
  border-bottom: 1px dashed rgba(226, 232, 240, 1);
}

.timeLabel:last-child { border-bottom: none; }

.gridArea {
  position: relative;
  display: grid;
  grid-template-rows: 40px 1fr;
  border-radius: var(--card-radius-lg);
  border: 1px solid var(--base-color-border);
  background: linear-gradient(180deg, rgba(248, 250, 252, 0.9) 0%, #fff 100%);
  overflow: hidden;
}

.dayHeaderRow {
  display: grid;
  grid-template-columns: repeat(var(--day-count), minmax(0, 1fr));
  background: #f8fafc;
  border-bottom: 1px solid rgba(226, 232, 240, 0.9);
  position: sticky;
  top: 0;
  z-index: 6;
}

.dayHeader {
  font-size: 12px;
  font-weight: 700;
  color: #334155;
  display: flex;
  align-items: center;
  justify-content: center;
  border-right: 1px solid rgba(226, 232, 240, 0.8);
}

.dayHeader:last-child { border-right: none; }

.dayHeader.today {
  color: #1d4ed8;
  background: rgba(59, 130, 246, 0.08);
}

.dayColumns {
  display: grid;
  grid-template-columns: repeat(var(--day-count), minmax(0, 1fr));
  height: 100%;
}

.dayColumn {
  position: relative;
  border-right: 1px solid rgba(226, 232, 240, 0.8);
}
.dayColumn:last-child { border-right: none; }

.gridCell {
  position: relative;
  border-bottom: 1px solid rgba(226, 232, 240, 0.8);
  cursor: pointer;
  touch-action: pan-y;
}

.gridCell:hover { background: rgba(59, 130, 246, 0.05); }
.gridCell:last-child { border-bottom: none; }

.tick {
  position: absolute;
  left: 12px;
  top: 50%;
  width: 16px;
  height: 1px;
  background: rgba(148, 163, 184, 0.8);
}

.selectionOverlay {
  position: absolute;
  left: 0;
  right: 0;
  background: rgba(59, 130, 246, 0.12);
  border-top: 1px solid rgba(59, 130, 246, 0.35);
  border-bottom: 1px solid rgba(59, 130, 246, 0.35);
  z-index: 2;
  pointer-events: none;
}

.hoverTip {
  position: fixed;
  z-index: 9999;
  background: rgba(15, 23, 42, 0.9);
  color: #fff;
  font-size: 12px;
  padding: 6px 10px;
  border-radius: 8px;
  pointer-events: none;
  white-space: nowrap;
}

/* 课程块 */
.lessonBlock {
  position: absolute;
  left: 12px;
  right: 12px;
  padding: 10px;
  border-radius: 12px;
  background: rgba(59, 130, 246, 0.12);
  border: 1px solid rgba(59, 130, 246, 0.35);
  box-shadow: 0 10px 20px rgba(59, 130, 246, 0.16);
  display: grid;
  gap: 6px;
  transition: all 0.2s;
  cursor: pointer;
  z-index: 4;
}

.lessonBlock:hover {
  transform: translateY(-2px);
  box-shadow: 0 14px 24px rgba(59, 130, 246, 0.2);
  z-index: 10;
}

/* 预置颜色（支持正式/体验/抗遗忘） */
.block-blue {
  background: rgba(59, 130, 246, 0.12);
  border-color: rgba(59, 130, 246, 0.35);
  box-shadow: 0 10px 20px rgba(59, 130, 246, 0.16);
}
.block-blue .lessonTitle { color: #1d4ed8; }
.block-blue .enterBtn { color: #1d4ed8; border-color: rgba(59, 130, 246, 0.5); }

.block-green {
  background: rgba(34, 197, 94, 0.12);
  border-color: rgba(34, 197, 94, 0.35);
  box-shadow: 0 10px 20px rgba(34, 197, 94, 0.16);
}
.block-green .lessonTitle { color: #15803d; }
.block-green .enterBtn { color: #15803d; border-color: rgba(34, 197, 94, 0.5); }

.block-orange {
  background: rgba(249, 115, 22, 0.12);
  border-color: rgba(249, 115, 22, 0.35);
  box-shadow: 0 10px 20px rgba(249, 115, 22, 0.16);
}
.block-orange .lessonTitle { color: #c2410c; }
.block-orange .enterBtn { color: #c2410c; border-color: rgba(249, 115, 22, 0.5); }

.block-yellow {
  background: rgba(234, 179, 8, 0.14);
  border-color: rgba(234, 179, 8, 0.45);
  box-shadow: 0 10px 20px rgba(234, 179, 8, 0.16);
}
.block-yellow .lessonTitle { color: #a16207; }
.block-yellow .enterBtn { color: #a16207; border-color: rgba(234, 179, 8, 0.55); }

.lessonTitle { font-weight: 800; color: #1f2937; font-size: 14px; }
.lessonTime { font-size: 12px; color: rgba(55, 65, 81, 0.8); }

.enterBtn {
  justify-self: start;
  height: 28px;
  padding: 0 10px;
  background: #fff;
}

@media (max-width: 767.98px) {
  .scheduleGrid { grid-template-columns: 72px 1fr; }
}
</style>
