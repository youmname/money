<script setup>
import { computed, ref, watch } from 'vue'
import BaseButton from '@/components/base/BaseButton.vue'

const props = defineProps({
  open: { type: Boolean, default: false },
  students: { type: Array, default: () => [] },
  stageOptions: { type: Array, default: () => [] },
  courseOptions: { type: Array, default: () => [] },
  selectedIds: { type: Array, default: () => [] },
  allowMultiple: { type: Boolean, default: false },
  allowManual: { type: Boolean, default: false },
  preferredStage: { type: String, default: '' },
  preferredCourse: { type: String, default: '' },
})

const emit = defineEmits(['update:open', 'confirm'])

const keyword = ref('')
const stageFilter = ref('all')
const courseFilter = ref('all')
const localSelected = ref([])
const manualName = ref('')
const manualPhone = ref('')
const manualStage = ref('')

watch(
  () => props.open,
  (val) => {
    if (!val) return
    localSelected.value = Array.isArray(props.selectedIds) ? [...props.selectedIds] : []
    manualName.value = ''
    manualPhone.value = ''
    manualStage.value = ''
  },
  { immediate: true }
)

function scoreStudent(stu) {
  let score = 0
  if (props.preferredStage && stu.stage === props.preferredStage) score += 2
  if (props.preferredCourse && stu.registered?.includes(props.preferredCourse)) score += 3
  return score
}

const filteredStudents = computed(() => {
  const kw = keyword.value.trim().toLowerCase()
  return props.students
    .filter((s) => {
      if (stageFilter.value !== 'all' && s.stage !== stageFilter.value) return false
      if (courseFilter.value !== 'all') {
        if (!s.registered?.includes(courseFilter.value)) return false
      }
      if (kw) {
        const target = `${s.name || ''} ${s.phone || ''}`.toLowerCase()
        if (!target.includes(kw)) return false
      }
      return true
    })
    .map((s) => ({ ...s, _score: scoreStudent(s) }))
    .sort((a, b) => b._score - a._score)
})

function toggleSelect(id) {
  if (!props.allowMultiple) {
    localSelected.value = [id]
    return
  }
  if (localSelected.value.includes(id)) {
    localSelected.value = localSelected.value.filter((v) => v !== id)
  } else {
    localSelected.value = [...localSelected.value, id]
  }
}

function close() {
  emit('update:open', false)
}

function confirm() {
  emit('confirm', {
    ids: localSelected.value,
    manual: {
      name: manualName.value.trim(),
      phone: manualPhone.value.trim(),
      stage: manualStage.value || '',
    },
  })
  close()
}
</script>

<template>
  <div v-if="open" class="modalMask" @click="close">
    <div class="modalPanel wide" @click.stop>
      <div class="modalHeader">
        <div class="modalTitle">选择学生</div>
        <button class="modalClose" @click="close">×</button>
      </div>

      <div class="modalBody">
        <div class="filterRow">
          <input v-model="keyword" class="input" placeholder="搜索学生姓名/联系方式" />
          <select v-model="stageFilter" class="input">
            <option value="all">全部学段</option>
            <option v-for="s in stageOptions" :key="s.id" :value="s.id">{{ s.name }}</option>
          </select>
          <select v-model="courseFilter" class="input">
            <option value="all">全部课程</option>
            <option v-for="c in courseOptions" :key="c" :value="c">{{ c }}</option>
          </select>
        </div>

        <div class="tableWrap">
          <table class="dataTable">
            <thead>
              <tr>
                <th class="colSelect">选择</th>
                <th>学生姓名</th>
                <th>学段</th>
                <th>关联课程</th>
                <th>联系方式</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="s in filteredStudents" :key="s.id">
                <td class="colSelect">
                  <input
                    :type="allowMultiple ? 'checkbox' : 'radio'"
                    :checked="localSelected.includes(s.id)"
                    @change="toggleSelect(s.id)"
                  />
                </td>
                <td>{{ s.name }}</td>
                <td>{{ stageOptions.find(o => o.id === s.stage)?.name || s.stage }}</td>
                <td>{{ (s.registered || []).join('、') || '-' }}</td>
                <td>{{ s.phone || '-' }}</td>
              </tr>
              <tr v-if="filteredStudents.length === 0">
                <td colspan="5" class="emptyRow">暂无匹配学生</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div v-if="allowManual" class="manualBox">
          <div class="manualTitle">体验课可手动录入</div>
          <div class="manualRow">
            <input v-model="manualName" class="input" placeholder="学生姓名（必填）" />
            <input v-model="manualPhone" class="input" placeholder="联系方式（必填）" />
            <select v-model="manualStage" class="input">
              <option value="">学段（可选）</option>
              <option v-for="s in stageOptions" :key="s.id" :value="s.id">{{ s.name }}</option>
            </select>
          </div>
        </div>
      </div>

      <div class="modalFooter">
        <BaseButton variant="ghost" class="ghostBtn" @click="close">取消</BaseButton>
        <BaseButton class="primaryBtn" @click="confirm">确认</BaseButton>
      </div>
    </div>
  </div>
</template>

<style scoped>
.modalMask {
  position: fixed;
  inset: 0;
  background: rgba(15, 23, 42, 0.4);
  display: grid;
  place-items: center;
  z-index: 80;
}
.modalPanel {
  width: min(980px, 92vw);
  background: #fff;
  border-radius: 16px;
  border: 1px solid #e2e8f0;
  box-shadow: 0 24px 60px rgba(15, 23, 42, 0.2);
  display: flex;
  flex-direction: column;
  max-height: 84vh;
}
.modalPanel.wide { width: min(1080px, 94vw); }
.modalHeader {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  border-bottom: 1px solid #e2e8f0;
}
.modalTitle { font-size: 16px; font-weight: 900; color: #0f172a; }
.modalClose { border: none; background: transparent; font-size: 22px; cursor: pointer; color: #475569; }
.modalBody { padding: 16px 20px; overflow: auto; }
.modalFooter {
  padding: 12px 20px;
  border-top: 1px solid #e2e8f0;
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}
.filterRow {
  display: grid;
  grid-template-columns: 1.2fr 0.7fr 0.7fr;
  gap: 10px;
  margin-bottom: 12px;
}
.input {
  height: 36px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 0 10px;
  font-size: 13px;
  color: #334155;
}
.tableWrap { border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; }
.dataTable { width: 100%; border-collapse: collapse; font-size: 13px; }
.dataTable th, .dataTable td { padding: 10px 12px; border-bottom: 1px solid #eef2f7; text-align: left; }
.dataTable thead th { background: #f8fafc; color: #475569; font-weight: 700; }
.colSelect { width: 56px; text-align: center; }
.emptyRow { text-align: center; color: #94a3b8; padding: 18px 0; }
.manualBox {
  margin-top: 14px;
  padding: 12px;
  border: 1px dashed #cbd5f5;
  border-radius: 10px;
  background: #f8fafc;
}
.manualTitle { font-size: 12px; font-weight: 800; color: #334155; margin-bottom: 8px; }
.manualRow { display: grid; grid-template-columns: 1fr 1fr 0.7fr; gap: 10px; }
</style>
